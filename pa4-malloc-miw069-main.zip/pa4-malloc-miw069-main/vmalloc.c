#include "vm.h"
#include "vmlib.h"
#include <stdio.h>

void *vmalloc(size_t size)
{
	printf("%d\n", size);
    	size = ((size+sizeof(struct block_header))+15) & ~15;
	printf("%d\n", size);
	
	struct block_header *block = heapstart;
	void *ptr = NULL;
	size_t bestSize  = 5000;
	struct block_header *bestFit = NULL;
	//size_t blockSize = block->size_status & ~3;
	//int a_or_not = block->size_status & 1;
	


	while(block->size_status!= VM_ENDMARK){
		size_t blockSize = block->size_status & ~3;
		printf("size: %d\n", blockSize);
		size_t a_or_not = block->size_status & 1;
		printf("allocated or not: %d\n", a_or_not);
		
		if(a_or_not == 0i && blockSize >=size){
			if(blockSize <bestSize ){
				bestSize = blockSize;	
				bestFit = block;		
			

			if(bestSize == size){
				ptr = (struct block_header*)((char *)bestFit + sizeof(struct block_header));
				bestFit->size_status|=1;
				struct block_header *nextb = (struct block_header*)((char*)bestFit + blockSize);
					nextb->size_status|= 1 << 1;
				return ptr;
				}
			}
			
		}	
		block = (struct block_header *)((char *)block + blockSize);

	}
	if(bestFit == 0){return NULL;}
	size_t remain = bestSize-size;
	if(remain >= (sizeof(struct block_header)+16)){
		struct block_header *newBlock = (struct block_header*)((char *)bestFit + size);
		newBlock->size_status = remain | 0;
		struct block_header *nextBlock = (struct block_header*)((char *)newBlock + remain);
		
		if(nextBlock->size_status != VM_ENDMARK){
			nextBlock->size_status &= ~2;
		}
		bestFit ->size_status = size |3;
	}else{
	
		bestFit->size_status |= 1;
	
	
	}


		struct block_header *nextBlock = (struct block_header *)((char *)bestFit + bestSize);
   	    if (nextBlock->size_status != VM_ENDMARK) {
       			 nextBlock->size_status |=2; 
   	 	} 
	printf("fit in %d\n", bestSize);
	printf("size Status: %d\n", bestFit->size_status);
	    ptr = (void *)((char *)bestFit + sizeof(struct block_header));
	    return ptr;
	

	
			
}
