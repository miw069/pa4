#include "vm.h"
#include "vmlib.h"

/**
 * The vmfree() function frees the memory space pointed to by ptr,
 * which must have been returned by a previous call to vmmalloc().
 * Otherwise, or if free(ptr) has already been called before,
 * undefined behavior occurs.
 * If ptr is NULL, no operation is performed.
 */
void vmfree(void *ptr)
{
	if(ptr != NULL){
		
		struct block_header *b = (struct block_header *)ptr;
		size_t size = b->size_status & ~3;

		if (b->size_status & 1) {
          		  b->size_status &= ~1; 
		
		struct block_header *nextb = (struct block_header*)((char *)b + size);
		  
              	  if (!(nextb->size_status & 1)) { 
                  	  size += nextb->size_status & ~3; 
              	  }
        	    

		}	
		b->size_status = size | 0;	
	}
	
	
	
	}





